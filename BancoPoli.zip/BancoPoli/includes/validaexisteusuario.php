<?php  
include("conexion.php"); 
$usuario = $_POST["usuario"];
$contrasena = MD5($_POST["password"]);

$sqlusuario ="SELECT * FROM RegistroUsuarios WHERE username = '".$usuario."'"; 
$queryusuario = $con->query($sqlusuario);
    
$sqlpassword ="SELECT * FROM RegistroUsuarios WHERE username = '".$usuario."' and password = '".$contrasena."' "; 
$querypassword = $con->query($sqlpassword);
    
    if($queryusuario->num_rows>0)
    {
        if($querypassword->num_rows>0)
        {
            echo "<script>alert('USUARIO REGISTRADO'); window.location.assign('../CuentaCliente.php')</script>";
        }
        else
        {
             echo "<script>alert('USUARIO O CONTRASEÑA INCORRECTA');window.location.assign('../index.php')</script>";
        }
    }
    else
    {
        echo "<script>alert('USUARIO NO REGISTRADO, ¡POR FAVOR, REGISTRATE!.'); window.location.assign('../registro.php') </script>";
    }
?>
