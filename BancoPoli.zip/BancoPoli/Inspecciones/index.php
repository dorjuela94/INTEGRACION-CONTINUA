<?php 
session_start();
if(!isset($_SESSION["session_name"])) {
	header("location:../");
} else {
?>



 <?php  
 include("../includes/conexion.php");
 $query = "SELECT * FROM revision where estado='Abierta' order by id asc";  
 $result = mysqli_query($con, $query);  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>YAMAKI</title> 
   
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
		   <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      </head>  
      <body>  
           <br /><br />  
           <div class="container" style="width:800px;">  
                <h3 align="center">INSPECCIONES ABIERTAS</h3>  
                <br />  
                <div class="table-responsive">  
                     <div >  
                        <a  href="../intropage.php" class="btn btn-default">Regresar</a>	
						
						<button type="button" name="add" id="add" data-toggle="modal" data-target="#add_data_Modal" class="btn btn-warning">+</button>  
                     </div>  
                     <br />  
                     <div id="employee_table">  
                          <table class="table table-bordered">  
                               <tr>  
                                    <th >INSPECCION</th>  
									<th >DOCUMENTO</th>  
									<th >FECHA IMPORTACION</th>  
                                    <th ></th>  
                               </tr>  
                               <?php  
                               while($row = mysqli_fetch_array($result))  
                               {  
                               ?>  
                               <tr>  
                                    <td><a title="Ver" href="./detalles_revision.php?id=<?php echo $row[0];?>" title="Detalles" ><?php echo $row["titulo"]; ?> </a></td> 
									<td><?php echo $row["do_importacion"]; ?></td> 
									<td><?php echo $row["fecha_importacion"]; ?></td> 
									
									<td>
			
								
	
	<a href="#" id="del2-<?php echo $row[0];?>" title="Eliminar" class="btn btn-sm btn-danger"><span class="glyphicon glyphicon-remove"></span></a>
		<script>
		$("#del2-"+<?php echo $row[0];?>).click(function(e){
			e.preventDefault();
			p = confirm("Desea Eliminar la Inspección?");
			if(p){
				window.location="./php/eliminar_revision.php?id="+<?php echo $row[0];?>;

			}

		});
		</script>								
									
									
									
									</td>  
                               </tr>  
                               <?php  
                               }  
                               ?>  
                          </table>  
                     </div>  
                </div>  
           </div>  
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">DETALLES INSPECCIÓN</h4>  
                </div>  
                <div class="modal-body" id="detalles_inspeccion">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 
 
 
 <div id="add_data_Modal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">INSPECCIÓN</h4>  
                </div>  
                <div class="modal-body">  
                     <form method="post" id="insert_form"> 
	
                <div class="modal-body">  
                     <form method="post" id="insert_form"> 
	
	
<br />  

<br />  
<table class="table table-bordered">
<tr><td><label for="Marca">FECHA INICIO REVISION</label><input readonly type="date" value="<?php echo date('Y-m-d'); ?>"  class="form-control" id="fecha" name="fecha" required /></td>
<td><label for="Empresa">EMPRESA</label> 
	<select class="form-control" name="empresa" required>
		<!--<option selected value=""> Elige una opción </option>-->
		<?php
		include "../includes/conexion.php";
		$sql1= "SELECT id_empresa, empresa from empresa ";
		$query = $con->query($sql1);
		if($query->num_rows>0){
			 while ($r=$query->fetch_array()){
				 echo "<option value=$r[1]>$r[1]</option> ";
			 }
		}
		?>
	</select>
	</td></tr>
<tr><td colspan="2"><label for="Hostname">REFERENCIA</label> <input  AUTOFOCUS onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" type="text"  value="" class="form-control" id="titulo" name="titulo" required></td></tr>



<tr>
<td><label for="Hostname">DOCUMENTO IMPORTACION</label> 
<input  onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" type="text"  value="" class="form-control" id="do_importacion" name="do_importacion" required></td>
<td><label for="Marca">FECHA IMPORTACION</label>
<input type="date" value="<?php echo date('Y-m-d'); ?>"  class="form-control" id="fecha_importacion" name="fecha_importacion" required /></td>
</tr>
<tr>
<td><label for="Hostname">CANTIDAD IMPORTACION</label> 
<input  onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" type="text"  value="" class="form-control" id="cant_importacion" name="cant_importacion" required></td>
<td><label for="Hostname">CANTIDAD A INSPECCIONAR</label> 
<input  onKeyUp="this.value=this.value.toUpperCase();" autocomplete="off" type="text"  value="" class="form-control" id="cant_inspeccion" name="cant_inspeccion" required></td>
</tr>
<tr><td colspan="2"><label >COMENTARIOS INICIALES</label>
 <textarea  rows="10" cols="50" autocomplete="off" type="text"  value="" class="form-control" id="comentarios_ini" name="comentarios_ini" required></textarea></td></tr>
</table>


   
                          <br />  
                          <input type="HIDDEN" name="idd" id="idd" />  
                          <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-success" /> 
                     </form>  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 </div>
 
 
 
 
 	 
 <div class="modal fade" id="cerrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
          <h4 class="modal-title">CERRAR INSPECCIÓN</h4>
        </div>
        <div class="modal-body">
		
<form role="form" method="post" action="php/aprobar_revision.php">
 <label >COMENTARIOS FINALES</label> 
 <textarea  rows="10" cols="50" autocomplete="off" type="text"  value="" class="form-control" id="comentarios_final" name="comentarios_final" required></textarea>
                          <br />  
                          <input type="hidden" value="<?php echo $datos->id; ?>" name="id" id="id" />  
						  <input type="hidden" value="cerrar" name="accion" id="accion" />  
                          <input type="submit" name="insert" id="insert" value="Guardar" class="btn btn-primary" /> 
</form>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div><!-- /.modal -->
      
 
 
 
 
 
 
 <script>  
 $(document).ready(function(){  
      $('#add').click(function(){  
           $('#insert').val("Guardar");  
           $('#insert_form')[0].reset();  
      });  
      $(document).on('click', '.edit_data', function(){  
           var ida = $(this).attr("id"); 
		   $.ajax({  
                url:"fetch_inspeccion.php",  
                method:"POST",  
                data:{id:ida},  
                dataType:"json",  
                success:function(data){  
					 $('#idd').val(data.id);  
                     $('#titulo').val(data.titulo);  
                     $('#empresa').val(data.empresa);  
                     $('#comentarios_ini').val(data.comentarios_ini);  
                     $('#fecha').val(data.fecha);  
                     $('#estado').val(data.estado);  
                     $('#insert').val("Actualizar");  
                     $('#add_data_Modal').modal('show');  
                }  
           });  
      });  
      $('#insert_form').on("submit", function(event){  
           event.preventDefault();  
                $.ajax({  
                     url:"insert_inspeccion.php",  
                     method:"POST",  
                     data:$('#insert_form').serialize(),  
                     beforeSend:function(){  
                          $('#insert').val("Guardando");  
                     },  
                     success:function(data){  
                          $('#insert_form')[0].reset();  
                          $('#add_data_Modal').modal('hide');  
                          $('#employee_table').html(data);  
                     }  
                });  
             
      });  
      $(document).on('click', '.view_data', function(){  
           var id = $(this).attr("id");  
           if(id != '')  
           {  
                $.ajax({  
                     url:"select_inspeccion.php",  
                     method:"POST",  
                     data:{id:id},  
                     success:function(data){  
                          //$('#employee_detail').html(data);  
						  $('#detalles_inspeccion').html(data);  
                          $('#dataModal').modal('show');  
                     }  
                });  
           }            
      });  
 });  
 </script>
 <?php
 
}

?>